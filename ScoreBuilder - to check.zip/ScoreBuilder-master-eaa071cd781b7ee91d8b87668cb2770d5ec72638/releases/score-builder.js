//ScoreBuilder © 2016

//Build Version: 1.0.0
//Build Date: 01-04-2016

"use strict";

//Usefull functions to help parse DOMs

var DOMUtils = {

    foreachChild: function(targetElem, childrenTasks) {

        //Iterate thry all the element children
        for (var i = 0; i < targetElem.children.length; i++) {
            var child = targetElem.children[i];

            //If the current child got its name on the childrenTask, execute the task passing the child ref
            if(childrenTasks[child.nodeName])
                childrenTasks[child.nodeName].call(targetElem, child);  
        }
    },

    getNodeAttributes: function(targetNode) {

        if(targetNode.attributes == undefined)
            return {};

        if(targetNode.attributes.length == 0)
            return {};

        var nodeAttributtes = {}

        for(var i = 0; i < targetNode.attributes.length; i++) {
            var currAttr = targetNode.attributes[i];

            nodeAttributtes[currAttr.nodeName] = currAttr.nodeValue;
        }

        return nodeAttributtes;
    },

    //Function to parse XML strings to xml dom
    parseXmlDom: function (xmlString) {
        var xmlDom = null;

        if (window.DOMParser) {

            try { 
                xmlDom = (new DOMParser()).parseFromString(xmlString, "text/xml"); 
            } catch (e) { 
                xmlDom = null; 
            }

        } else if (window.ActiveXObject) {

            try {
                xmlDom = new ActiveXObject('Microsoft.XMLDOM');
                xmlDom.async = false;
                if (!xmlDom.loadXML(xmlString)) // parse error ..
                    xmlDom = null;
                    //window.alert(xmlDom.parseError.reason + xmlDom.parseError.srcText);
            } catch (e) { 
                xmlDom = null; 
            }

        } else {
            xmlDom = null;
            //console.error("Cannot parse xml string!");
        }        

        return xmlDom;
    }
}


/*function getNoteDen(type) {
    var currDenominator = null;

    switch(type) {
        case "whole":
            currDenominator = 1;
            break;

        case "half":
            currDenominator = 2;
            break;

        case "quarter":
            currDenominator = 4;
            break;

        case "eighth":
            currDenominator = 8;
            break;

        case "16th":
            currDenominator = 16;
            break;

        case "32nd":
            currDenominator = 32;
            break;

        case "64th":
            currDenominator = 64;
            break;

        case "128th":
            currDenominator = 128;
            break;

        default:
            if(type == undefined) {
                currDenominator = 1;
            } else {
                console.log("Denominator not implemented: ");
                console.log(type);
                //throw "Denominator not implemented: " + measures[i].note[j]; 
            }                                               
    }

    return currDenominator;
}*/

var MusicXmlConverter = {}

MusicXmlConverter.toJson = function (xmlFile) {
    
    var xmlDOM;
    if(typeof xmlFile == 'string')
        xmlDOM = DOMUtils.parseXmlDom(xmlFile);
    else
        xmlDOM = xmlFile;
    
    var parsedFile;

    //Check if it got a score partwise object
    DOMUtils.foreachChild(xmlDOM, {

        //if the current child is a score partwise, parse it
        'score-partwise': function(currChild) {
            parsedFile = parseScorePartwise(currChild);
        }

        //In the future add score-timewise
    });

    if(parsedFile === undefined)
        throw "Parse Error: Invalid MusicXML File.";
        
    return parsedFile;            
}

//Function to parse <attributes> node

function parseAttributes(attrNode) {

	var attrObject = {
		name: 'attributes'
	}

	DOMUtils.foreachChild(attrNode, {

		'divisions': function(divisionsNode) {
			//Not in use due to influentiate only in music reproduction, not score sheet
			//attrObject.divisions = divisionsNode.textContent;
		},

		'key': function(keyNode) {
			attrObject.key = parseKey(keyNode);
		},

		'time': function(timeNode) {
			attrObject.time = parseTime(timeNode);
		},

		'clef': function(clefNode) {
			attrObject.clef = parseClef(clefNode);
		}

	});

	return attrObject;
}
function parseBar(barNode) {

    var barObj = {
        'name': 'bar',
        'location': 'right' //Default location right
    }

    var scoreBarAttr = DOMUtils.getNodeAttributes(barNode);

    if(scoreBarAttr.hasOwnProperty('location'))
        barObj['location'] = scoreBarAttr['location'];

    if(scoreBarAttr.hasOwnProperty('segno'))
        barObj['segno'] = scoreBarAttr['segno'];

    if(scoreBarAttr.hasOwnProperty('coda'))
        barObj['coda'] = scoreBarAttr['coda'];

    if(scoreBarAttr.hasOwnProperty('divisions'))
        barObj['divisions'] = scoreBarAttr['divisions'];


    DOMUtils.foreachChild(barNode, {

        'bar-style': function(styleNode) {
            barObj['bar-style'] = styleNode.textContent;      
        },

        'repeat': function(repeatNode) {
            var repeatAttr = DOMUtils.getNodeAttributes(repeatNode);
            if(repeatAttr.hasOwnProperty('direction'))
               barObj['repeat'] = repeatAttr['direction'];

        },

        'ending': function(endingNode) {

        },

    });

    return barObj;
}

//Function to parse the <clef> node
function parseClef(clefNode) {

    var clefObject = {}

    DOMUtils.foreachChild(clefNode, {

        'sign': function(signNode) {
            clefObject.sign = signNode.textContent;
        },

        'line': function(lineNode) {
            clefObject.line = lineNode.textContent;
        },

        'clef-octave-change': function(cocNode) {
            clefObject['clef-octave-change'] = cocNode.textContent;
        }
    });

    return clefObject;
}






function parseClef2(scoreClef) {

    //If it got less than 2 children, means invalid clef, return null
    if(scoreClef.children.length < 2)
        return null;

    var clefObj = {}

    //Iterate thry clefs child
    for(var i = 0; i < scoreClef.children.length; i++) {
        var clefChild = scoreClef.children[i];

        switch(clefChild.nodeName) {
            case "sign":
                clefObj.sign = clefChild.textContent;
                break;

            case "line":
                clefObj.line = clefChild.textContent;
                break;
        }
    }

    //If some of the members are not defined, return null
    if(clefObj.sign == undefined || clefObj.line == undefined)
        return null;

    return clefObj.sign + clefObj.line;
}

//Function to parse <key> node

function parseKey(keyNode) {

	var keyValue;

	DOMUtils.foreachChild(keyNode, {
		'fifths': function(fifthsNode) {
			keyValue = fifthsNode.textContent;	
		}
	});

	return keyValue;
}
//Function to get the key sig object based on its music xml key tag
function parseKeySig(scoreKey) {
    //If it got less than 2 children, means invalid key, return null
    if(scoreKey.children.length < 1)
        return null;

    var keySigValue = null;

    //Iterate thry key childs
    for(var i = 0; i < scoreKey.children.length; i++) {
        var keyChild = scoreKey.children[i];

        switch(keyChild.nodeName) {
            case "fifths":
                keySigValue = parseInt(keyChild.textContent);
                break;
        }
    }

    //if the key sig value is not valid, return null, other wise, return itself
    if(isNaN(keySigValue))
        return null;

    return keySigValue;
}

//function to parse <measure> nodes

function parseMeasure(measureNode) {

	var measureObject = { members: [] }

	var measureNodeAttr = DOMUtils.getNodeAttributes(measureNode);


	//Required Attributes

	if(measureNodeAttr.number == undefined)
		return null;

	measureObject.number = measureNodeAttr.number;

	//Optional attributes

	if(measureNodeAttr.implicit != undefined)
		measureObject.implicit = measureNodeAttr.implicit;

	if(measureNodeAttr['non-controlling'] != undefined)
		measureObject['non-controlling'] = measureNodeAttr['non-controlling'];

	if(measureNodeAttr.width != undefined)
		measureObject.width = measureNodeAttr.width;


	var lastMember = null;

	//Iterate thru children
	DOMUtils.foreachChild(measureNode, {

		'note': function(noteNode) {
			var noteObject = parseNote(noteNode);

			//Last member to be used to parse chords
			//var lastMember = measureObject.members.length == 0 ? null : 
				//measureObject.members[measureObject.members.length - 1];

			//Verify object if we should create new chord object for it
			if(lastMember == null ||	//if the last member is not set
				lastMember.name != 'note' || //if the last member is set but is not a note
				noteObject.isRest ||	//If the current object is a rest 
				//If the last object and the current object have diferent grace values
				(noteObject.hasOwnProperty('grace') != lastMember.hasOwnProperty('grace')),
				!noteObject.isChord	//if the current object is not member of a chord
				) {

				var chordObject = {
					name: 'note',
					keys: [noteObject],
					type: noteObject.type,
					stem: noteObject.stem
				}

				if(noteObject.hasOwnProperty('grace')) {
					chordObject['grace'] = noteObject['grace'];

					if(noteObject.hasOwnProperty('slash'))
						chordObject['slash'] = noteObject['grace']['slash'];	
				}

				//create new note object with keys element and type(duration) of the first member
				measureObject.members.push(chordObject);

				lastMember = chordObject;

			} else {
				lastMember.keys.push(noteObject);
			}
		},

		'backup': function() {

		},

		'forward': function() {

		},

		'direction': function() {

		},

		'attributes': function(attrNode) {
			var attrObject = parseAttributes(attrNode);
			measureObject.members.push(attrObject);

			//Updates the last member of the measure
			lastMember = attrObject;
		},

	  	'harmony': function() {

		},

	  	'figured-bass': function() {

		},

	  	'print': function() {

		},

	  	'sound': function() {

		},

	  	'barline': function(barNode) {
	  		var barObject = parseBar(barNode);
	  		measureObject.members.push(barObject);

	  		//Updates the last member of the measure
	  		lastMember = barObject;	
		},

	  	'grouping': function() {

		},

	  	'link': function() {

		},

	  	'bookmark': function() {

		}

	});

	return measureObject;
}
//Function to parse <note> objects

function parseNote(noteNode) {

	var noteArr = [];

	var noteObject = { 
		//name: 'note',
		isRest: false,
		isChord: false,
		type: 'whole'	//Set default type whole
	}

	DOMUtils.foreachChild(noteNode, {

		'pitch': function(pitchNode) {
			noteObject.pitch = parsePitch(pitchNode);
		},

		'duration': function(durationNode) {
			//Not in use due to influentiate only in music reproduction, not score sheet
			//noteObject.duration = durationNode.textContent;
		},

		'voice': function(voiceNode) {
			noteObject.voice = voiceNode.textContent;
		},

		'rest': function() {
			noteObject.isRest = true;
		},

		'chord': function() {
			noteObject.isChord = true;
		},

		'type': function(typeNode) {
			noteObject.type = typeNode.textContent;
		},

		'stem': function(stemNode) {
			noteObject.stem = stemNode.textContent;
		},

		'accidental': function(accidentalNode) {

			var accAttributes = DOMUtils.getNodeAttributes(accidentalNode);

			noteObject.accidental = { 
				type: accidentalNode.textContent
			}

			if(accAttributes['parentheses'] ==  'yes')
				noteObject.accidental.cautionary = true;
		}, 

		'grace': function(graceNode) {
			var graceAttributes = DOMUtils.getNodeAttributes(graceNode);

			noteObject.grace = {
				//Attr when it is a slashed grace note
				slash: graceAttributes.slash == 'yes' ? true : false
			}
		}

	});


	return noteObject;	
}
//Function to parse <part> nodes

function parsePart(partNode) {

	//Get part attributes
	var partNodeAttr = DOMUtils.getNodeAttributes(partNode);

	//If there is no id (REQUIRED), return null
	if(partNodeAttr.id == undefined)
		return null;

	var partObject = {
		id: partNodeAttr.id,
		measures: []
	}

	DOMUtils.foreachChild(partNode, {

		'measure': function(measureNode) {
			var measureObject = parseMeasure(measureNode);

			//If it is a valid measure object
			if(measureObject != null)
				partObject.measures.push(measureObject);
		}

	});

	return partObject;
}
//Function to parse <pitch> node
function parsePitch(pitchNode) {

	var pitchObject = {}

	DOMUtils.foreachChild(pitchNode, {

		'step': function(stepNode) {
			pitchObject.step = stepNode.textContent;
		},

		'octave': function(octaveNode) {
			pitchObject.octave = octaveNode.textContent;
		},

		'alter': function(alterNode) {
			//Not in use due to influentiate only in music reproduction, not score sheet
			//pitchObject.alter = alterNode.textContent;
		}

	});

	return pitchObject;
}
function parseScoreMeasure(scoreMeasure) {

    function createMeasure() {
        return { chords: [] , chordPointer: -1, endBar: "light" } 
    }


    //modify this to parse every node that may appear on measure
    //and put them into an array called members




    var measuresCollection = [],
        measuresMetadata = {}

    //Iterate thru scoreMeasure childs
    for(var i = 0; i < scoreMeasure.children.length; i++) {
        var currChild = scoreMeasure.children[i];

        switch(currChild.nodeName) {
            case "attributes":
                //iterate thru the attributes children
                for(var j = 0; j < currChild.children.length; j++) {
                    var attrChild = currChild.children[j];

                    switch(attrChild.nodeName) {
                        case "clef":
                            var clefObj = parseClef(attrChild);

                            if(clefObj == null) //If the clef obj is not found,
                                break;  //exit

                            var clefAttr = DOMUtils.getNodeAttributes(attrChild);

                            //if there is no number attribute at the clef, 
                            if(clefAttr.number == undefined) {
                                measuresMetadata.clef = clefObj;
                            } else {  //if there is number attr
                                var partInd = clefAttr.number - 1;  //set its number subtracting 1

                                //Check if the measure specified by the clef has already been created, if not create it
                                if(measuresCollection[partInd] == undefined)
                                    measuresCollection[partInd] = createMeasure();

                                measuresCollection[partInd].clef = clefObj;   
                            }

                            break;

                        case "key":
                            var keySigObj = parseKeySig(attrChild);
                            if(keySigObj != null)
                                measuresMetadata.keySig = keySigObj; 
                            break;

                        case "time":
                            var timeSigObj = parseTimeSig(attrChild);
                            if(timeSigObj != null)
                                measuresMetadata.timeSig = timeSigObj;
                            break;
                    }
                }
                break;

            case "direction": //measure tempo will be found here
                var tempoObj = parseTempo(currChild);
                if(tempoObj != null)
                    measuresMetadata.tempo = tempoObj;
                break;

            case "barline":
                var barObj = parseBar(currChild);
                if(barObj != undefined && barObj.name != undefined) {
                    if(barObj.place == "start")
                        measuresMetadata.startBar = barObj.name;    
                    else if(barObj.place == "end")
                        measuresMetadata.endBar = barObj.name;   
                }
                break;

            case "note":

                var noteObj = parseScoreNote(currChild);

                //get the part index of the note
                var partInd = noteObj.partInd;
                delete noteObj.partInd; //delete part index member from the note obj

                if(measuresCollection[partInd] == undefined)
                    measuresCollection[partInd] = createMeasure();

                //Get the note measure reference
                var measureRef = measuresCollection[partInd];

                if(noteObj.chordFlag == undefined || measureRef.chordPointer == -1) { 
                    measureRef.chordPointer++; //increase chord pointer 
                    measureRef.chords[measureRef.chordPointer] = { notes:[] , denominator: 1}  //inits the new chord object
                } else {
                    delete noteObj.chordFlag;   //if it is a chord, only delete this member
                }

                var currChord = measureRef.chords[measureRef.chordPointer];

                if(noteObj.dot != undefined) {
                    currChord.dot = noteObj.dot;
                    delete noteObj.dot;
                }

                if(noteObj.denominator != undefined) {
                    currChord.denominator = noteObj.denominator;
                    delete noteObj.denominator;
                }

                if(noteObj.slur != undefined) {
                    currChord.slur = noteObj.slur;
                    delete noteObj.slur;
                }

                if(noteObj.tied != undefined) {
                    currChord.tied = noteObj.tied;
                    delete noteObj.tied;
                }

                if(noteObj.step != undefined && noteObj.octave != undefined)
                    currChord.notes.push(noteObj);

                break;
        }
    }

    //Add metadata to the measures and remove unecessary members
    for(var i = 0; i < measuresCollection.length; i++) {
        var currMeasure = measuresCollection[i];
        
        delete currMeasure.chordPointer;  

        //Copy all properties of the measure metadata to the measures on the measure collection
        for(var prop in measuresMetadata)
            currMeasure[prop] = measuresMetadata[prop];    
    }

    return measuresCollection;
}
function parseScoreNote(scoreNote) {
    
    var noteObj = { partInd: 0 }    //note object to store note information with the part index of the note

    for(var i = 0; i < scoreNote.children.length; i++) {
        var noteChild = scoreNote.children[i];

        switch(noteChild.nodeName) {

            //Get note denominator
            case "type":
                noteObj.denominator = getNoteDen(noteChild.textContent);
                break;

            case "pitch":

                for(var j = 0; j < noteChild.children.length; j++) {
                    var pitchChild = noteChild.children[j];

                    switch(pitchChild.nodeName) {

                        case "step":
                            noteObj.step = pitchChild.textContent;
                            break;

                        case "octave":
                            var noteOctave = parseInt(pitchChild.textContent);
                            noteObj.octave = isNaN(noteOctave) ? null : noteOctave;
                            break;
                    }
                }
                break;

            case "accidental":
                noteObj.accidental = noteChild.textContent; 
                break;

            case "dot":
                //if the dot stuff hasn't been defined yet, define it as one,
                if(noteObj.dot == undefined)
                    noteObj.dot = 1;
                else //if it has already been defined, update to 2
                    noteObj.dot = 2;
                break;

            case "chord":
                noteObj.chordFlag = true;
                break;

            case "voice":
                var noteVoice = parseInt(noteChild.textContent);                    

                //If the note voice is a valid number, get the part index from it
                if(!isNaN(noteVoice))
                    noteObj.partInd = parseInt((noteVoice - 1) / 4); 

                break;

            case "notations":
                for(var j = 0; j < noteChild.children.length; j++) {
                    var notationsChild = noteChild.children[j];

                    switch(notationsChild.nodeName) {

                        case "slur":
                            var slurAttr = DOMUtils.getNodeAttributes(notationsChild);
                            if(slurAttr.type != undefined)
                                noteObj.slur = slurAttr.type;    

                            break;

                        case "tied":
                            var tiedAttr = DOMUtils.getNodeAttributes(notationsChild);
                            if(tiedAttr.type != undefined)
                                noteObj.tied = tiedAttr.type;                               

                            break;
                    }
                }

                break;
        }
    }

    return noteObj;
}
function parseScorePartwise(scorePartwise) {

    var newPartwise = { parts: [] };

    var scorePartwiseAttr = DOMUtils.getNodeAttributes(scorePartwise);

    if(scorePartwiseAttr.version != undefined)
        newPartwise.version = scorePartwiseAttr.version;   

    DOMUtils.foreachChild(scorePartwise, {

        'movement-title': function(currChild) {
            //If the title has already been set, put the setted as subtitle
            if(newPartwise.title != undefined)
                newPartwise.subtitle = newPartwise.textContent; 
            
            newPartwise.title = currChild.textContent;
        },

        'work': function(currChild) {
            //iterate thru the work children

            DOMUtils.foreachChild(currChild, {

                'work-title': function(workChild) {
                    if(newPartwise.title == undefined) 
                        newPartwise.title = workChild.textContent;
                    else
                        newPartwise.subtitle = workChild.textContent;
                }

            });
        },

        'identification': function(currChild) {

            DOMUtils.foreachChild(currChild, {

                'creator':function(identChild) {
                    var creatorAttr = DOMUtils.getNodeAttributes(identChild);
                    if(creatorAttr.type != undefined)
                        newPartwise[creatorAttr.type] = identChild.textContent;
                }

            });
        },

        'part': function(currChild) {
            //Get the parts of the score
            //var partsColl = parseScorePart(currChild);

            var partsColl = [parsePart(currChild)];

            //Push all the parts to the new partwise parts array
            for(var j = 0; j < partsColl.length; j++)
                newPartwise.parts.push(partsColl[j]);
        }

    });

    return newPartwise;
}

function parseTempo(scoreTempo) {

    var tempoObj = {};

    for(var i = 0; i < scoreTempo.children.length; i++) {
        var scoreTempoChild = scoreTempo.children[i];

        switch(scoreTempoChild.nodeName) {

            case "direction-type":
                for(var j = 0; j < scoreTempoChild.children.length; j++) {
                    var directionTypeChild = scoreTempoChild.children[j];

                    switch(directionTypeChild.nodeName) {

                        case "metronome":
                            for(var l = 0; l < directionTypeChild.children.length; l++) {
                                var metronomeChild = directionTypeChild.children[l];

                                switch(metronomeChild.nodeName) {

                                    case "beat-unit":

                                        switch(metronomeChild.textContent) {
                                            case "eighth":
                                                tempoObj.denominator = 8;
                                                break;

                                            case "quarter":
                                                tempoObj.denominator = 4;
                                                break;

                                            case "half":
                                                tempoObj.denominator = 2;
                                                break;
                                        }

                                        break;

                                    case "per-minute":
                                        tempoObj.value = metronomeChild.textContent;
                                        break;
                                }
                            }
                            break;
                    }
                }
                break;
        }
    }

    if(tempoObj.value == undefined || tempoObj.denominator == undefined)
        return null;

    return tempoObj;
}
//Function to parse <time> node

function parseTime(timeNode) {

	var timeObject = {}

	var timeAttr = DOMUtils.getNodeAttributes(timeNode);

	if(timeAttr['symbol'] != undefined)
		timeObject['symbol'] = timeAttr['symbol'];

	DOMUtils.foreachChild(timeNode, {

		'beats': function(beatsNode) {
			timeObject['beats'] = beatsNode.textContent;	
		},

		'beat-type': function(beatTypeNode) {
			timeObject['beat-type'] = beatTypeNode.textContent;
		}

	});

	return timeObject;
}
//Function to get the time sig object based on its music xml key tag
function parseTimeSig(scoreTime) {
    
    //Check if the score got a symbol on its attributes
    var scoreTimeAttr = DOMUtils.getNodeAttributes(scoreTime);

    //if so, return this symbol as the time sig object
    if(scoreTimeAttr.symbol != undefined)
        return scoreTimeAttr.symbol;

    //If not, proceed

    //If it got less than 2 children, means invalid time sig, return null
    if(scoreTime.children.length < 2)
        return null;

    var timeSigObj = {}

    //Iterate thry time childs
    for(var i = 0; i < scoreTime.children.length; i++) {
        var timeChild = scoreTime.children[i];

        switch(timeChild.nodeName) {
            case "beats":
                timeSigObj.beats = timeChild.textContent;
                break;

            case "beat-type":
                timeSigObj.beatType = timeChild.textContent;
                break;
        }
    }

    //If some of the members are not defined, return null
    if(timeSigObj.beats == undefined || timeSigObj.beatType == undefined)
        return null;

    return timeSigObj.beats + "," + timeSigObj.beatType; 

}
//Main object declaration

var Parti = {}

Parti.Score = function() {

	var staffs = [];

	//console.log(new Vex.Flow.Formatter());
	//console.log([Vex.Flow.Formatter]);

	this.addStaff = function(staff) {
		staffs.push(staff);
	}

	function getChordsLength(chords) {

		// Start by creating a voice and adding all the notes to it.
    	var voice = new Vex.Flow.Voice(Vex.Flow.TIME4_4)
      		.setMode(Vex.Flow.Voice.Mode.SOFT);
    
    	voice.addTickables(chords);

    	var formater = new Vex.Flow.Formatter();
    	return formater.preCalculateMinTotalWidth([voice]);
	}

	this.render = function() {

		var scoreLines = [];
		var scoreLinesIndex = -1;	//Start index with -1 to initiate it correcly

		//Iterate thru staffs and measures and populate score lines array
		for (var i = 0; i < staffs.length; i++) {

			var staffData = staffs[i];

			var currentClef = null;

			staffData.foreach(function(measureData, firstMeasure, lastMeasure, measureIndex) {

				var measureMembers = [];

				measureData.foreach(function(memberData, firstMember, lastMember) {

					if(memberData.name == 'chord') {

						if(currentClef == null)
							throw 'Invalid Chord: No clef has been set to the staff yet';

						var chordKeys = [];
						var chordDuration = getDurationName(memberData.getDuration());

						memberData.foreach(function(noteData) {
							chordKeys.push(noteData.note + "/" + noteData.octave);
						});

						var isRest = chordKeys.length == 0;

						measureMembers.push(new Vex.Flow.StaveNote({ 
							clef: currentClef,
							keys: isRest ? [getCenterString(currentClef)] : chordKeys, 
							duration: isRest ? chordDuration + 'r' : chordDuration,
							auto_stem: true
						}));

					} else if(memberData.name == 'clef') {
						currentClef = memberData.getClef();
					} 


				});

				var chordsLength = getChordsLength(measureMembers);

				//Check if the scoreLine array has been initiated, 
				//if its length is not overflowed and 
				//if its width is not overflowed

				if(scoreLinesIndex > -1 && 
					scoreLines[scoreLinesIndex].measures.length < 8 &&
					scoreLines[scoreLinesIndex].width + chordsLength < 1000) {

					scoreLines[scoreLinesIndex].measures.push(measureData);
					scoreLines[scoreLinesIndex].width += chordsLength;

				} else {
					//If not, increase score lines index, and add the current measuredata to it

					scoreLinesIndex++;
					scoreLines[scoreLinesIndex] = {
						measures: [measureData],
						width: chordsLength
					}

				}

					

			});
		}

		//Now we have the lines, we render them correctly

		var canvas = $("#score-container")[0];
		var renderer = new Vex.Flow.Renderer(canvas, Vex.Flow.Renderer.Backends.RAPHAEL);
		var context = renderer.getContext();

		var renderObjectsQueue = [];

		var renderWindowWidth = 1400;

		var measureVerticalPosPointer = 180;

		currentClef = null;	//reset the current clef
		var currentOctaveShift = 0;
		var currentClefAnnotation;

		var currentTime;
		var currentKey;

		var prevMeasure = null;
		var prevMeasureData = null;

		for (var i = 0; i < scoreLines.length; i++) {
			var scoreLine = scoreLines[i];

			for (var j = 0; j < scoreLine.measures.length; j++) {
				var measureData = scoreLine.measures[j];
				
				//Later we must add weights according to the line minimal space
				var measureWidth = renderWindowWidth / scoreLine.measures.length;

				var measureMembers = [];

				var measure = new Vex.Flow.Stave(j * (measureWidth + 10) + 20, 
					measureVerticalPosPointer, measureWidth)
					.setContext(context);

				//Place begin repeat bar if some or place a repeat both bar in the previous if needed

				if(measureData.getStartBar() == 'repeat_begin') {

					//If first measure of the line
					if(j == 0) {
						//Place the repeat begin bar
						measure.setBegBarType(getBarType('repeat_begin'));
					} else { //If not, 

						//Check if the prev measure
						if(prevMeasureData.getEndBar() == "repeat_end") {
							prevMeasure.setEndBarType(getBarType("repeat_both"));
							measure.setBegBarType(getBarType('none'));
						} else {
							prevMeasure.setEndBarType(getBarType("repeat_begin"));
							measure.setBegBarType(getBarType('none'));
						}
					}

				} else {
					measure.setBegBarType(getBarType('none'));
				}

				//Place end bar if there is some
				var endBar = measureData.getEndBar();
				if(endBar != 'none') {
					measure.setEndBarType(getBarType(endBar));
				}

				//Place the time signature
				var measureTimeSig = measureData.getTimeSignature();

				if(measureTimeSig && measureTimeSig != currentTime) {

					currentTime = measureTimeSig;

					if(j == 0)
						measure.setTimeSignature(currentTime);

					if(prevMeasure)
						prevMeasure.setEndTimeSignature(currentTime);							
				}

				//Place clef in case first measure and clef already signed
				if(j == 0 && currentClef) //first measure of the line
					measure.setClef(currentClef, "default", currentClefAnnotation);

				//Place the current key signature if there is some
				if(j == 0 && currentClef && currentKey)
					//Set the current key signature of the measure
					measure.setKeySignature(currentKey, undefined, undefined, currentClef);

				//Flag to signalize whether a note has already been placed in the measure
				var notePlacedFlag = false;

				//Queue to accumulate note beams to be rendered
				var noteBeamRenderQueue = [];
				var nbrqIndex = -1;	//Index for the note beam render queue

				//Pointer to hold the reference for the last memberData
				var lastMemberData = null;

				measureData.foreach(function(memberData, isFirstMember, isLastMember) {
					//TODO: Use the same data generated for the line to avoid process same thing twice
					if(memberData.name == 'chord') {

						notePlacedFlag = true;

						var chordKeys = [];
						var chordDuration = memberData.getDuration();

						//Queue to hold note accidents to be added at once
						var accidentalQueue = [];
						var accNoteIndex = 0;

						memberData.foreach(function(noteData) {
							chordKeys.push(noteData.note + "/" + noteData.octave);
							
							//Push the accidental to the queue if some
							if(noteData.accidental) {
								accidentalQueue.push({
									index: accNoteIndex,
									accidental: getAccidentalLetter(noteData.accidental.type),
									cautionary: noteData.accidental.cautionary
								});
							}

							accNoteIndex++;
						});

						var isRest = chordKeys.length == 0;

						var staveNote;

						if(memberData.hasOwnProperty('grace')) {

							staveNote = new Vex.Flow.GraceNote({ 
								octave_shift: currentOctaveShift,
								clef: currentClef,
								keys: isRest ? [getCenterString(currentClef, currentOctaveShift)] : chordKeys, 
								duration: isRest ? chordDuration + 'r' : chordDuration,
								auto_stem: memberData.stem ? false : true,
								stem_direction: memberData.stem == 'up' ? 1 : -1,
								slash: memberData.grace.slash
							});

							//If the duration is less than four, so no beam should be placed
							//(Here we use a hack, since the durations that have no beams return letters, not numbers)
							if(!isNaN(parseInt(memberData.getDuration()))) {
								//Check if a new grace group for beaming must be created
								if(lastMemberData == null || //if there is no last member data
									//if the last member were not a grace not
									!lastMemberData.hasOwnProperty('grace') || 
									//If the last member were a grace but with a smaller duration
									//(same hack as above)
									isNaN(parseInt(lastMemberData.getDuration()))) {

									nbrqIndex++;
									noteBeamRenderQueue[nbrqIndex] = [staveNote];	
								} else {
									console.log(lastMemberData.getDuration());
									noteBeamRenderQueue[nbrqIndex].push(staveNote);
								}
							}

						} else {

							staveNote = new Vex.Flow.StaveNote({ 
								octave_shift: currentOctaveShift,
								clef: currentClef,
								keys: isRest ? [getCenterString(currentClef, currentOctaveShift)] : chordKeys,
								auto_stem: memberData.stem ? false : true,
								stem_direction: memberData.stem == 'up' ? 1 : -1, 
								duration: isRest ? chordDuration + 'r' : chordDuration,
								auto_stem: true,
							});

						}

						//Add the queued accidentals to the stave note
						for (var accIndex = 0; accIndex < accidentalQueue.length; accIndex++) {
							var acc = accidentalQueue[accIndex];

							var accObj = new Vex.Flow.Accidental(acc.accidental);

							if(acc.cautionary)
								accObj.setAsCautionary();

							staveNote.addAccidental(acc.index, accObj);
						}

						measureMembers.push(staveNote);

					} else if(memberData.name == 'clef') {

						currentClef = memberData.getClef();
						var clefAnnotation = memberData.getAnnotation();

						//Validate and get annotations to supported clefs
						currentClefAnnotation = validateAnnotation(currentClef, clefAnnotation);

						//Get the octave shift value based on annotation for notes
						currentOctaveShift = getOctaveShift(currentClefAnnotation);


						if(notePlacedFlag) {
							
							//Verification to avoid overlapping of the clef symbol into the bars in case last clef
							if(isLastMember || false) {
								measure.setEndClef(currentClef, "small", currentClefAnnotation);
							} else {
								measureMembers.push(
									new Vex.Flow.ClefNote(currentClef, "small", currentClefAnnotation));
							}

						} else { //If notes were not placed yet

							if(j == 0) //first measure of the line
								measure.setClef(currentClef, "default", currentClefAnnotation);

							if(prevMeasure)
								prevMeasure.setEndClef(currentClef, "small", currentClefAnnotation);
						}
						

					} else if(memberData.name == 'key') {
						
						if(currentClef == undefined)
							throw 'Key Signature Error: No clef has been set yet.';

						//Place the measure key signature
						var measureKeySig = memberData.getKey();
						if(measureKeySig != currentKey) {
					
							currentKey = measureKeySig;

							//If it is there first line, set the key signature
							if(j == 0)
								measure.setKeySignature(currentKey, undefined, undefined, currentClef);

							//Set the prev measure the current signature
							if(prevMeasure)
								prevMeasure.setEndKeySignature(currentKey, undefined, currentClef);									
						}

					} 

					lastMemberData = memberData;
				});

				//Get the current member ref into the prev member var
				prevMeasure = measure;
				prevMeasureData = measureData;

				//Add objects to the render queue to be processed later

				renderObjectsQueue.push({
					type: 'measure',
					measure: measure
				});

				renderObjectsQueue.push({
					type: 'format',
					context: context,
					measure: measure,
					measureMembers: measureMembers
				});

				//Put beams to the render queue
				for (var nbIndex = 0; nbIndex < noteBeamRenderQueue.length; nbIndex++) {
					var noteBeamGroup = noteBeamRenderQueue[nbIndex];

					if(noteBeamGroup.length < 2)
						continue;

					renderObjectsQueue.push({
						type: 'beam',
						beam: new Vex.Flow.Beam(noteBeamGroup)
					});
				}

				stem high bug, stem does not grows, overlap other components must be fixed

			}

			measureVerticalPosPointer += 100;
		}

		//Now everything is prepared we may render it

		for (var i = 0; i < renderObjectsQueue.length; i++) {
			switch(renderObjectsQueue[i].type){

				//Draw measure
				case 'measure':
					renderObjectsQueue[i].measure.draw();
					break;

				//Format and position measure members
				case 'format':
					Vex.Flow.Formatter.FormatAndDraw(renderObjectsQueue[i].context, 
						renderObjectsQueue[i].measure, 
						renderObjectsQueue[i].measureMembers);	
					break;

				//Draw notes beams
				case 'beam':
					console.log('hola');
					renderObjectsQueue[i].beam.setContext(context).draw();
					break;
			}
		}
	}

	/*function getDurationName(durationValue) {

		switch(durationValue) {

			case 1:
				return 'w';

			case 2:
				return 'h';

			case 4:
				return 'q';

			default:
				return durationValue.toString();
		}
	}*/

	function validateAnnotation(clef, annotation) {
		var validAnnotation = annotation;	//Default the valid annotation with the argument

		if(annotation == '8va') {
			if(clef != 'treble') {
				console.warn('Not supported anottation for target clef: ' + 
					clef + ' ' + annotation + '. Clearing annotation.');
				validAnnotation = undefined; //If not valid, clear valid annotation
			}
		} else if(annotation == '8vb') {
			if(clef != 'treble' && clef != 'bass') {
				console.warn('Not supported anottation for target clef: ' + 
					clef + ' ' + annotation + '. Clearing annotation.');
				validAnnotation = undefined;
			}
		}

		return validAnnotation;
	}

	function getOctaveShift(annotation) {
		var octaveShift = 0;

		//Get the octave shift value based on annotation
		if(annotation == '8va')
			octaveShift = 1;
		else if(annotation == '8vb')
			octaveShift = -1;

		return octaveShift;
	}

	function getBarType(bar) {

		var barObj = Vex.Flow.Barline.type;

		switch(bar) {

			case 'single':
				return barObj.SINGLE;

			case 'double':
				return barObj.DOUBLE;

			case 'end':
				return barObj.END;

			case 'repeat_begin':
				return barObj.REPEAT_BEGIN;

			case 'repeat_end':
				return barObj.REPEAT_END;

			case 'repeat_both':
				return barObj.REPEAT_BOTH;

			case 'none':
				return barObj.NONE;

			default:
				return barObj.NONE;
		}
	}

	//Function to get the center note to place rest on the center of the stave
	function getCenterString(clef, octaveShift) {

		octaveShift = octaveShift || 0;

		var centerNote = 'b';
		var centerOctave = 4 + octaveShift;

		switch(clef) {

    		case "treble":
				centerNote = 'b';
				centerOctave = 4 + octaveShift;
				break;

    		case "bass":
				centerNote = 'd';
				centerOctave = 3 + octaveShift;
				break;

    		case "alto":
				centerNote = 'c';
				centerOctave = 4 + octaveShift;
				break;

    		case "tenor":
				centerNote = 'a';
				centerOctave = 3 + octaveShift;
				break;

    		case "percussion":
				//centerNote = 'b';
				//centerOctave = 4 + octaveShift;
				break;

    		case "soprano":
				centerNote = 'g';
				centerOctave = 4 + octaveShift;
				break;

    		case "mezzo-soprano":
				centerNote = 'e';
				centerOctave = 4 + octaveShift;
				break;

    		case "baritone-c":
				centerNote = 'f';
				centerOctave = 3 + octaveShift;
				break;

    		case "baritone-f":
				centerNote = 'f';
				centerOctave = 3 + octaveShift;
				break;

    		case "subbass":
				centerNote = 'b';
				centerOctave = 2 + octaveShift;
				break;

    		case "french":
				centerNote = 'd';
				centerOctave = 5 + octaveShift;
				break;

    		//case "tab":
				//centerNote = 'b';
				//centerOctave = 4 + octaveShift;
				//break;
		}

		return centerNote + "/" + centerOctave;
	}

	function getAccidentalLetter(acc) {
		switch(acc) {

			case 'sharp':
  				return "#";

  			case 'double-sharp':
 				return "##";

 			case 'sharp-sharp':
 				return "##";

 			case 'flat':
				return "b";

			case 'flat-flat':
				return "bb";

			case 'natural':
				return "n";


			//return "{"; {   // Left paren for cautionary accidentals

			//return "}"; {   // Right paren for cautionary accidentals

			/*case 'sharp':
				return "db";

			case 'sharp':
				return "d";

			case 'sharp':
				return "bbs";

			case 'sharp':
				return "++";

			case 'sharp':
				return "+";

			case 'sharp':
				return "+-";

			case 'sharp':
				return "++-";

			case 'sharp':
				return "bs";

			case 'sharp':
				return "bss";*/

			default:
				throw 'Accidental not implemented: ' + acc;
		}
	}
}
//Staff class

//How it works
//We must add all the measures, and them, when we render, it will iterate thru the measures and populate the staff members array
//All validation stuff will be made here, cause it may depend on other measures

Parti.Staff = function() {

	var measures = [];

	this.addMeasure = function(measure) {
		measures.push(measure);
	}

	this.count = function() {
		return measures.length;
	}

	this.foreach = function(callback) {

		for (var i = 0; i < measures.length; i++) {
			callback.call(this, measures[i], i == 0, i == measures.length - 1, i);
		}
	}
}
//Measure class

//How it works
//this will have things like, start bar, end bar, time sig and inner components (such notes, clefs, and key sigs)

Parti.Measure = function() {

	var self = this;

	var members = [];	//Members to be place into the measure (notes, clefs, timesigs, key sigs etc)

	this.addMember = function(member) {
		members.push(member);
		return self;
	}

	var _timeSignature;
	this.setTimeSignature = function(timeSig) {
		_timeSignature = timeSig;
		return self;			
	}
	this.getTimeSignature = function() { return _timeSignature; }
	

	var _keySignature = 'C';
	this.setKeySignature = function(keySig) {
		_keySignature = keySig;
		return self;			
	}
	this.getKeySignature = function() { return _keySignature; }


	var _startBar = 'none';
	this.setStartBar = function(barValue) { 
		_startBar = barValue; 
		return self;
	}
	this.getStartBar = function() { return _startBar; }

	var _endBar = 'single';
	this.setEndBar = function(barValue) { 
		_endBar = barValue; 
		return self;
	}
	this.getEndBar = function() { return _endBar; }

	this.foreach = function(callback) {

		for (var i = 0; i < members.length; i++) {
			callback.call(this, members[i], i == 0, i == members.length - 1);
		}
	}
}
Parti.Chord = function() {

	var self = this;

	var duration = 1;

	var notes = [];

	this.name = 'chord';

	this.addNote = function(note) {
		notes.push(note);
		return self;
	}

	//Function to sort notes order to avoid warnings on vexflow
	function sortNotes() {
		if(notes.length < 2)
			return;

		//Sort keys
		notes.sort(function(note1, note2) {
			var octave1 = note1.octave;
			var octave2 = note2.octave;

			if(octave1 == octave2) {
				var note1Code = note1.note.charCodeAt(0);
				note1Code = note1Code < 67 ? note1Code + 7 : note1Code;

				var note2Code = note2.note.charCodeAt(0);
				note2Code = note2Code < 67 ? note2Code + 7 : note2Code;

				return note1Code - note2Code;
			}

			return octave1 - octave2;
		});
	}

	this.setDuration = function(durationValue) {
		duration = durationValue;
		return self;
	}

	this.getDuration = function() {
		return duration;
	}

	this.foreach = function(callback) {
		//Sort notes first to avoid warning
		sortNotes();		

		for (var i = 0; i < notes.length; i++) {
			callback.call(this, notes[i], i == 0, i == notes.length - 1);		
		}
	}
}
Parti.Clef = function(clefName, annotation) {

	this.name = 'clef';

	//Clef value
	var _clef = clefName;
	this.getClef = function() {
		return _clef;
	}

	//Annotation in case octave change
	var _annotation = annotation;
	this.getAnnotation = function() {
		if(_clef == "treble" || _clef == "bass")
			return _annotation;

		return undefined;
	}
}
Parti.Key = function(keyName) {
	
	var key = keyName;

	this.name = 'key';

	this.getKey = function() {
		return key;
	}

	/*function getKeyName(keyVal) {

		switch(keyVal) {

			case '-7':
				return 'Cb';

			case '-6':
				return 'Gb';

			case '-5':
				return 'Db';

			case '-4':
				return 'Ab';

			case '-3':
				return 'Eb';

			case '-2':
				return 'Bb';

			case '-1':
				return 'F';

			case '1':
				return 'G';

			case '2':
				return 'D';

			case '3':
				return 'A';

			case '4':
				return 'E';

			case '5':
				return 'B';

			case '6':
				return 'F#';

			case '7':
				return 'C#';
		}	
	}*/
}
Parti.Time = function(timeValue) {
	
	var timeVal = timeValue;

	this.name = 'time';

	this.getTime = function() {
		return timeVal;
	}
}
function renderScore(mJson) {

	console.log(mJson);

	var score = new Parti.Score();

	foreach(mJson.parts, function(part) {

		var staff = new Parti.Staff();
		score.addStaff(staff);

		var staffNoteDivisions = 1;

		foreach(part.measures, function(measure) {

			var fileMeasure = new Parti.Measure();
			staff.addMeasure(fileMeasure);

			var lastChord = null;	//Last chord ref to handle notes

			foreach(measure.members, function(member) {

				if(member.name == 'attributes') {

					//Set the note divisions
					//Not in use due to influentiate only in music reproduction, not score sheet
					if(member.hasOwnProperty('divisions')) {
						//staffNoteDivisions = parseInt(member.divisions);
					}

					//If there is a clef on the attribute
					if(member.hasOwnProperty('clef')) {
						fileMeasure.addMember(new Parti.Clef(
							getClefName(member.clef.sign + member.clef.line),
							getClefOctaveAnnotation(member.clef['clef-octave-change']))
						);
					}

					if(member.hasOwnProperty('key')) {
						fileMeasure.addMember(new Parti.Key(getKeyName(member.key)));
					}

					if(member.hasOwnProperty('time')) {

						var timeSig;

						if(member.time.hasOwnProperty('symbol')) {
							timeSig = getTimeSymbol(member.time['symbol']);
						} else {
							timeSig = member.time['beats'] + '/' + member.time['beat-type'];
						}

						fileMeasure.setTimeSignature(timeSig);
					}

					//Clear last chord reference in case some attribute showup
					lastChord = null;

				} else if(member.name == 'note') {

					var fileChord = new Parti.Chord();
					fileMeasure.addMember(fileChord);

					//var chordDuration = getDurationName(4 * staffNoteDivisions / parseInt(member.duration));
					var chordDuration = getDurationName(member.type);

					fileChord.setDuration(chordDuration);

					if(member.hasOwnProperty('grace'))
						fileChord['grace'] = member['grace'];

					//Set stem direction
					fileChord.stem = member.stem;

					foreach(member.keys, function(key) {
						//If the key is not a rest
						if(!key.isRest) {
							var noteObj = { 
								note: key.pitch.step, 
								octave: key.pitch.octave 
							}

							if(key.accidental)
								noteObj.accidental = key.accidental;

							fileChord.addNote(noteObj);
						}
					});

				} else if(member.name == 'bar') {
					var barName = getBarValue(member['bar-style'], member.repeat);

					switch(member.location) {

						case 'left':
							fileMeasure.setStartBar(barName);
							break;

						case 'right':
							fileMeasure.setEndBar(barName);
							break;
					}
				}

			});

		});

	});

	score.render();
}


function renderScore2(mJson) {

	console.log(mJson);
	var canvas = $("canvas")[0];
	var renderer = new Vex.Flow.Renderer(canvas, Vex.Flow.Renderer.Backends.CANVAS);
	var ctx = renderer.getContext();
	

	foreach(mJson.parts, function(part) {
		renderStaff(ctx, part);
	});


}



function foreach(array, callback) {
	for (var i = 0; i < array.length; i++) {
		callback.call(this, array[i], i == 0, i == array.length - 1);
	}
}

function getClefName(clefString) {
	switch(clefString) {

		//G clefs
		
		case 'G1':
			return 'french';

		case 'G2':
			return 'treble';



		//F clefs

		case 'F3':
			return 'baritone-f';

		case 'F4':
			return 'bass';

		case 'F5':
			return 'subbass';


		//C clefs

		case 'C1':
			return 'soprano';

		case 'C2':
			return 'mezzo-soprano';

		case 'C3':
			return 'alto';

		case 'C4':
			return 'tenor';

		case 'C5':
			return 'baritone-c';
	}
}

function getClefOctaveAnnotation(octave) {

	if(octave === undefined)
		return undefined;

	switch(octave) {

		case '-1':
			return '8vb';

		case '1':
			return '8va';

		default:
			console.warn('Not Implemented annotation: ' + octave + '. Annotation supressed.');
			return undefined;
	}

}

function getKeyName(keyVal) {

	switch(keyVal) {

		case '-7':
			return 'Cb';

		case '-6':
			return 'Gb';

		case '-5':
			return 'Db';

		case '-4':
			return 'Ab';

		case '-3':
			return 'Eb';

		case '-2':
			return 'Bb';

		case '-1':
			return 'F';

		case '1':
			return 'G';

		case '2':
			return 'D';

		case '3':
			return 'A';

		case '4':
			return 'E';

		case '5':
			return 'B';

		case '6':
			return 'F#';

		case '7':
			return 'C#';
	}	
}

function getTimeSymbol(symbol) {

	switch(symbol) {

		case 'cut':
			return 'C|';

		case 'common':
			return 'C';
	}

	return symbol;

}

function getBarValue(bar, repeat) {

	switch(bar) {

		case 'regular':
			return 'single';
			
		case 'dotted':
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'dashed':
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'heavy':
			//Probably this bar does not exists
			return undefined;

		case 'light-light':
			return 'double';

		case 'light-heavy':
			if(repeat && repeat == 'backward')
				return 'repeat_end';
			else
				return 'end';

		case 'heavy-light':
			if(repeat && repeat == 'forward')
				return 'repeat_begin';
			else
				return undefined;

		case 'heavy-heavy':
			//Probably this bar does not exists
			return undefined;

		case 'tick': //(a short stroke through the top line)
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'short': //(a partial barline between the 2nd and 4th lines)
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'none':
			return 'none';
	}
}

function getDurationName(durationValue) {

	switch(durationValue) {

		case 1:
			return 'w';

		case 2:
			return 'h';

		case 4:
			return 'q';

//----------------------------------------

		//Not implemented on vexflow
		//case 'maxima':
		//case 'long':
		//case 'breve'

		case 'whole':
			return 'w';

		case 'half':
			return 'h';

		case 'quarter':
			return 'q';

		case 'eighth':
			return '8';

		case '16th':
			return '16';

		case '32nd':
			return '32';

		case '64th':
			return '64';

		case '128th':
			return '128';

		//case '256th':
		//case '512th':
		//case '1024th':

		default:
			return durationValue.toString();
	}
}



//Function to render the staff in the passed context

function renderStaff(context, partData) {

		var staff = new Vex.Flow.Stave(10, 200, 1450)
			.setContext(context);

		var staffNoteDivisions = 1;
		var staffMembers = [];

		foreach(partData.measures, function(measure, isFirst, isLast) {

			var currentClef = 'treble';

			foreach(measure.members, function(member) {

				if(member.name == 'attributes') {
					
					if(isFirst)	{

						if(member.divisions != undefined)
							staffNoteDivisions = parseInt(member.divisions);
						
						if(member.time != undefined)
							staff.setTimeSignature(member.time['beats'] + '/' + member.time['beat-type']);
						
						if(member.clef != undefined) {
							var clefName = getClefName(member.clef.sign + member.clef.line);
							currentClef = clefName;
							staff.setClef(clefName);
						}
						
						if(member.key != undefined && member.key != 0)
							staff.setKeySignature(getKeyName(member.key));

					} else {

						if(member.clef != undefined) {
							
							var clefName = getClefName(member.clef.sign + member.clef.line);
							currentClef = clefName;
							staffMembers.push(new Vex.Flow.ClefNote(clefName, 'small'));
						}
					}

				} if(member.name == 'note') {

					var noteDuration = getDurationName(1) + 'r';
					var noteKeys = [];

					foreach(member.keys, function(key) {

						noteDuration = getDurationName(4 * staffNoteDivisions / parseInt(key.duration));

						if(key.isRest) {
							noteKeys.push('b/4');
							noteDuration += 'r';

						} else {
							noteKeys.push(key.pitch.step + "/" + key.pitch.octave);	
						}								
					});

					staffMembers.push(new Vex.Flow.StaveNote({ 
						clef: currentClef,
						keys: noteKeys, 
						duration: noteDuration,
						auto_stem: true
					}));
				}

			});

			if(!isLast)
				staffMembers.push(new Vex.Flow.BarNote().setType(Vex.Flow.Barline.type.SINGLE));
		});

		//Draw stave
		staff.draw();

		// Helper function to justify and draw a 4/4 voice
  		Vex.Flow.Formatter.FormatAndDraw(context, staff, staffMembers);






}
//Function to render the score measures
function renderMeasure(measure, staff) {


	//create object to wrap vexflow components and improve the objectification of the score,
	//creating measures etc


}
function renderExample() {

	//write in a way that each measure is a stave object
	//verify how each line will be spaced, for now, create a fixed space between them
	console.log('KEYSIGNATURE');
	console.log(new Vex.Flow.KeySignature('Cb'));

	var chordExample = new Parti.Chord();
	chordExample
		.setDuration('1');
		//.addNote({ note: 'G', octave: '4' })
		//.addNote({ note: 'B', octave: '4' })
		//.addNote({ note: 'D', octave: '4' });

	var measureExample = new Parti.Measure();

	var clefExample = new Parti.Clef('treble');

	measureExample
		.setTimeSignature('3/8')
		.addMember(clefExample)
		.addMember(new Parti.Key('G'))
		.addMember(chordExample)
		.addMember(new Parti.Clef('bass'))
		.addMember(chordExample)
		.setStartBar('repeat_begin')
		.setEndBar('end');


	var measureExample2 = new Parti.Measure();
	measureExample2
		.addMember(new Parti.Clef('bass'))
		.addMember(new Parti.Key('Cb'))
		.setEndBar('end');
		



	var staffExample = new Parti.Staff();
	staffExample.addMeasure(measureExample);
	staffExample.addMeasure(measureExample2);
	staffExample.addMeasure(measureExample);




	var scoreExample = new Parti.Score();
	scoreExample.addStaff(staffExample);

	scoreExample.render();
}
console.log('');
console.log('-------TODO LIST-------');

function todo(msg) {
	console.log('-> ' + msg);
}

todo('Become a competitor to the existing one');
todo('No open source for a while');

todo('keep adding render features, such notes, rests, beams, slurs etc');
todo('Fix bug in case time signature product odd durations values');
todo('Fix bug that stem do not extend to the middle of the score lines');
todo('create proper project to store this');
todo("keep doing the music xml parser");
todo('create lib musicxmlgraphreducer, a that will have only the graphical data of the music xml, simplified but will use all music xml tag names');
todo('If ibr works, we will buy envi.ae and revive qeek.me');
todo('use the visual test vex flow uses');
todo('focus on brazilian market');
todo('main screen will have popular scores, with images or colors created based on the music');
todo('improve the new lines rules');
todo('stem high bug, stem does not grows, overlap other components must be fixed')


console.log('-------------------------');
console.log(' ');