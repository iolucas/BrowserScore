
var MusicXmlConverter = {}

MusicXmlConverter.toJson = function (xmlFile) {
    
    var xmlDOM;
    if(typeof xmlFile == 'string')
        xmlDOM = DOMUtils.parseXmlDom(xmlFile);
    else
        xmlDOM = xmlFile;
    
    var parsedFile;

    //Check if it got a score partwise object
    DOMUtils.foreachChild(xmlDOM, {

        //if the current child is a score partwise, parse it
        'score-partwise': function(currChild) {
            parsedFile = parseScorePartwise(currChild);
        }

        //In the future add score-timewise
    });

    if(parsedFile === undefined)
        throw "Parse Error: Invalid MusicXML File.";
        
    return parsedFile;            
}
