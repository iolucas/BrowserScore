//Function to parse <key> node

function parseKey(keyNode) {

	var keyValue;

	DOMUtils.foreachChild(keyNode, {
		'fifths': function(fifthsNode) {
			keyValue = fifthsNode.textContent;	
		}
	});

	return keyValue;
}