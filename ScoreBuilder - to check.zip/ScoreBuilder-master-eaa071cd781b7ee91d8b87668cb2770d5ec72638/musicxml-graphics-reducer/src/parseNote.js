//Function to parse <note> objects

function parseNote(noteNode) {

	var noteArr = [];

	var noteObject = { 
		//name: 'note',
		isRest: false,
		isChord: false,
		type: 'whole'	//Set default type whole
	}

	DOMUtils.foreachChild(noteNode, {

		'pitch': function(pitchNode) {
			noteObject.pitch = parsePitch(pitchNode);
		},

		'duration': function(durationNode) {
			//Not in use due to influentiate only in music reproduction, not score sheet
			//noteObject.duration = durationNode.textContent;
		},

		'voice': function(voiceNode) {
			noteObject.voice = voiceNode.textContent;
		},

		'rest': function() {
			noteObject.isRest = true;
		},

		'chord': function() {
			noteObject.isChord = true;
		},

		'type': function(typeNode) {
			noteObject.type = typeNode.textContent;
		},

		'stem': function(stemNode) {
			noteObject.stem = stemNode.textContent;
		},

		'accidental': function(accidentalNode) {

			var accAttributes = DOMUtils.getNodeAttributes(accidentalNode);

			noteObject.accidental = { 
				type: accidentalNode.textContent
			}

			if(accAttributes['parentheses'] ==  'yes')
				noteObject.accidental.cautionary = true;
		}, 

		'grace': function(graceNode) {
			var graceAttributes = DOMUtils.getNodeAttributes(graceNode);

			noteObject.grace = {
				//Attr when it is a slashed grace note
				slash: graceAttributes.slash == 'yes' ? true : false
			}
		}

	});


	return noteObject;	
}