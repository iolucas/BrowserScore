function parseBar(barNode) {

    var barObj = {
        'name': 'bar',
        'location': 'right' //Default location right
    }

    var scoreBarAttr = DOMUtils.getNodeAttributes(barNode);

    if(scoreBarAttr.hasOwnProperty('location'))
        barObj['location'] = scoreBarAttr['location'];

    if(scoreBarAttr.hasOwnProperty('segno'))
        barObj['segno'] = scoreBarAttr['segno'];

    if(scoreBarAttr.hasOwnProperty('coda'))
        barObj['coda'] = scoreBarAttr['coda'];

    if(scoreBarAttr.hasOwnProperty('divisions'))
        barObj['divisions'] = scoreBarAttr['divisions'];


    DOMUtils.foreachChild(barNode, {

        'bar-style': function(styleNode) {
            barObj['bar-style'] = styleNode.textContent;      
        },

        'repeat': function(repeatNode) {
            var repeatAttr = DOMUtils.getNodeAttributes(repeatNode);
            if(repeatAttr.hasOwnProperty('direction'))
               barObj['repeat'] = repeatAttr['direction'];

        },

        'ending': function(endingNode) {

        },

    });

    return barObj;
}
