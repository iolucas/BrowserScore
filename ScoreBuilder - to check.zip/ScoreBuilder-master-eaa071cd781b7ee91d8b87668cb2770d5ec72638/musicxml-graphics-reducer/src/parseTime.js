//Function to parse <time> node

function parseTime(timeNode) {

	var timeObject = {}

	var timeAttr = DOMUtils.getNodeAttributes(timeNode);

	if(timeAttr['symbol'] != undefined)
		timeObject['symbol'] = timeAttr['symbol'];

	DOMUtils.foreachChild(timeNode, {

		'beats': function(beatsNode) {
			timeObject['beats'] = beatsNode.textContent;	
		},

		'beat-type': function(beatTypeNode) {
			timeObject['beat-type'] = beatTypeNode.textContent;
		}

	});

	return timeObject;
}