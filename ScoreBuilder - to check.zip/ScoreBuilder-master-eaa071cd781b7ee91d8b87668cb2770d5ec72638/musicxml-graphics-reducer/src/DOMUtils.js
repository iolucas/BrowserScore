//Usefull functions to help parse DOMs

var DOMUtils = {

    foreachChild: function(targetElem, childrenTasks) {

        //Iterate thry all the element children
        for (var i = 0; i < targetElem.children.length; i++) {
            var child = targetElem.children[i];

            //If the current child got its name on the childrenTask, execute the task passing the child ref
            if(childrenTasks[child.nodeName])
                childrenTasks[child.nodeName].call(targetElem, child);  
        }
    },

    getNodeAttributes: function(targetNode) {

        if(targetNode.attributes == undefined)
            return {};

        if(targetNode.attributes.length == 0)
            return {};

        var nodeAttributtes = {}

        for(var i = 0; i < targetNode.attributes.length; i++) {
            var currAttr = targetNode.attributes[i];

            nodeAttributtes[currAttr.nodeName] = currAttr.nodeValue;
        }

        return nodeAttributtes;
    },

    //Function to parse XML strings to xml dom
    parseXmlDom: function (xmlString) {
        var xmlDom = null;

        if (window.DOMParser) {

            try { 
                xmlDom = (new DOMParser()).parseFromString(xmlString, "text/xml"); 
            } catch (e) { 
                xmlDom = null; 
            }

        } else if (window.ActiveXObject) {

            try {
                xmlDom = new ActiveXObject('Microsoft.XMLDOM');
                xmlDom.async = false;
                if (!xmlDom.loadXML(xmlString)) // parse error ..
                    xmlDom = null;
                    //window.alert(xmlDom.parseError.reason + xmlDom.parseError.srcText);
            } catch (e) { 
                xmlDom = null; 
            }

        } else {
            xmlDom = null;
            //console.error("Cannot parse xml string!");
        }        

        return xmlDom;
    }
}


/*function getNoteDen(type) {
    var currDenominator = null;

    switch(type) {
        case "whole":
            currDenominator = 1;
            break;

        case "half":
            currDenominator = 2;
            break;

        case "quarter":
            currDenominator = 4;
            break;

        case "eighth":
            currDenominator = 8;
            break;

        case "16th":
            currDenominator = 16;
            break;

        case "32nd":
            currDenominator = 32;
            break;

        case "64th":
            currDenominator = 64;
            break;

        case "128th":
            currDenominator = 128;
            break;

        default:
            if(type == undefined) {
                currDenominator = 1;
            } else {
                console.log("Denominator not implemented: ");
                console.log(type);
                //throw "Denominator not implemented: " + measures[i].note[j]; 
            }                                               
    }

    return currDenominator;
}*/