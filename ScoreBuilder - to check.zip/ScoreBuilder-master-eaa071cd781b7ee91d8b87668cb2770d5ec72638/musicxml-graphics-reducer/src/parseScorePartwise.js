function parseScorePartwise(scorePartwise) {

    var newPartwise = { parts: [] };

    var scorePartwiseAttr = DOMUtils.getNodeAttributes(scorePartwise);

    if(scorePartwiseAttr.version != undefined)
        newPartwise.version = scorePartwiseAttr.version;   

    DOMUtils.foreachChild(scorePartwise, {

        'movement-title': function(currChild) {
            //If the title has already been set, put the setted as subtitle
            if(newPartwise.title != undefined)
                newPartwise.subtitle = newPartwise.textContent; 
            
            newPartwise.title = currChild.textContent;
        },

        'work': function(currChild) {
            //iterate thru the work children

            DOMUtils.foreachChild(currChild, {

                'work-title': function(workChild) {
                    if(newPartwise.title == undefined) 
                        newPartwise.title = workChild.textContent;
                    else
                        newPartwise.subtitle = workChild.textContent;
                }

            });
        },

        'identification': function(currChild) {

            DOMUtils.foreachChild(currChild, {

                'creator':function(identChild) {
                    var creatorAttr = DOMUtils.getNodeAttributes(identChild);
                    if(creatorAttr.type != undefined)
                        newPartwise[creatorAttr.type] = identChild.textContent;
                }

            });
        },

        'part': function(currChild) {
            //Get the parts of the score
            //var partsColl = parseScorePart(currChild);

            var partsColl = [parsePart(currChild)];

            //Push all the parts to the new partwise parts array
            for(var j = 0; j < partsColl.length; j++)
                newPartwise.parts.push(partsColl[j]);
        }

    });

    return newPartwise;
}
