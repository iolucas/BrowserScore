//Function to parse <pitch> node
function parsePitch(pitchNode) {

	var pitchObject = {}

	DOMUtils.foreachChild(pitchNode, {

		'step': function(stepNode) {
			pitchObject.step = stepNode.textContent;
		},

		'octave': function(octaveNode) {
			pitchObject.octave = octaveNode.textContent;
		},

		'alter': function(alterNode) {
			//Not in use due to influentiate only in music reproduction, not score sheet
			//pitchObject.alter = alterNode.textContent;
		}

	});

	return pitchObject;
}