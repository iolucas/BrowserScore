//Function to parse <attributes> node

function parseAttributes(attrNode) {

	var attrObject = {
		name: 'attributes'
	}

	DOMUtils.foreachChild(attrNode, {

		'divisions': function(divisionsNode) {
			//Not in use due to influentiate only in music reproduction, not score sheet
			//attrObject.divisions = divisionsNode.textContent;
		},

		'key': function(keyNode) {
			attrObject.key = parseKey(keyNode);
		},

		'time': function(timeNode) {
			attrObject.time = parseTime(timeNode);
		},

		'clef': function(clefNode) {
			attrObject.clef = parseClef(clefNode);
		}

	});

	return attrObject;
}