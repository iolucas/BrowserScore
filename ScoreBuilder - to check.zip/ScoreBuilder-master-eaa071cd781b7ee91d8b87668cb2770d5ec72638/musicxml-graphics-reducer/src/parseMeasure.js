//function to parse <measure> nodes

function parseMeasure(measureNode) {

	var measureObject = { members: [] }

	var measureNodeAttr = DOMUtils.getNodeAttributes(measureNode);


	//Required Attributes

	if(measureNodeAttr.number == undefined)
		return null;

	measureObject.number = measureNodeAttr.number;

	//Optional attributes

	if(measureNodeAttr.implicit != undefined)
		measureObject.implicit = measureNodeAttr.implicit;

	if(measureNodeAttr['non-controlling'] != undefined)
		measureObject['non-controlling'] = measureNodeAttr['non-controlling'];

	if(measureNodeAttr.width != undefined)
		measureObject.width = measureNodeAttr.width;


	var lastMember = null;

	//Iterate thru children
	DOMUtils.foreachChild(measureNode, {

		'note': function(noteNode) {
			var noteObject = parseNote(noteNode);

			//Last member to be used to parse chords
			//var lastMember = measureObject.members.length == 0 ? null : 
				//measureObject.members[measureObject.members.length - 1];

			//Verify object if we should create new chord object for it
			if(lastMember == null ||	//if the last member is not set
				lastMember.name != 'note' || //if the last member is set but is not a note
				noteObject.isRest ||	//If the current object is a rest 
				//If the last object and the current object have diferent grace values
				(noteObject.hasOwnProperty('grace') != lastMember.hasOwnProperty('grace')),
				!noteObject.isChord	//if the current object is not member of a chord
				) {

				var chordObject = {
					name: 'note',
					keys: [noteObject],
					type: noteObject.type,
					stem: noteObject.stem
				}

				if(noteObject.hasOwnProperty('grace')) {
					chordObject['grace'] = noteObject['grace'];

					if(noteObject.hasOwnProperty('slash'))
						chordObject['slash'] = noteObject['grace']['slash'];	
				}

				//create new note object with keys element and type(duration) of the first member
				measureObject.members.push(chordObject);

				lastMember = chordObject;

			} else {
				lastMember.keys.push(noteObject);
			}
		},

		'backup': function() {

		},

		'forward': function() {

		},

		'direction': function() {

		},

		'attributes': function(attrNode) {
			var attrObject = parseAttributes(attrNode);
			measureObject.members.push(attrObject);

			//Updates the last member of the measure
			lastMember = attrObject;
		},

	  	'harmony': function() {

		},

	  	'figured-bass': function() {

		},

	  	'print': function() {

		},

	  	'sound': function() {

		},

	  	'barline': function(barNode) {
	  		var barObject = parseBar(barNode);
	  		measureObject.members.push(barObject);

	  		//Updates the last member of the measure
	  		lastMember = barObject;	
		},

	  	'grouping': function() {

		},

	  	'link': function() {

		},

	  	'bookmark': function() {

		}

	});

	return measureObject;
}