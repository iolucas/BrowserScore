module.exports = function(grunt) {

	// Project configuration. 
	grunt.initConfig({
      pkg: grunt.file.readJSON('package.json'),
  		concat: {
    		dist: {
      			src: [ //select all javascript files of the src folder

              //Music xml reducer files

              'musicxml-graphics-reducer/src/*.js',
              

              //Score builder Files
              //Must list each one to ensure correct declaration order (to be fixed)

              'score-builder/src/Parti.js',
              'score-builder/src/Score.js',
              'score-builder/src/Staff.js',
              'score-builder/src/Measure.js',
              'score-builder/src/Chord.js',
              'score-builder/src/Clef.js',
              'score-builder/src/Key.js',
              'score-builder/src/Time.js',

              'score-builder/src/render.js',
              'score-builder/src/renderStaff.js',
              'score-builder/src/renderMeasure.js',

              'score-builder/src/renderExample.js',

              'score-builder/src/todolist.js'
            ], 
      			dest: 'releases/score-builder.js', //target to the concatened files
    		},

        options: {
          banner: '//ScoreBuilder © 2016\n\n' +
          '//Build Version: <%= pkg.version %>\n' + 
          '//Build Date: <%= grunt.template.today("dd-mm-yyyy") %>\n\n' +
          '"use strict";\n\n'

        }
  		},

      /*uglify: {
        options: {
          compress: {
            drop_console: true
          }
        },
        my_target: {
          files: {
            'releases/musicxml-converter.min.js': ['releases/musicxml-converter.js']
          }
        }
      },*/
      //Every time some js file change, concatenate them to the release version
      watch: {
        scripts: {
          files: [              
              'musicxml-graphics-reducer/src/*.js',
              'score-builder/src/*.js',
              'tests/index.html'
          ],
          tasks: ['concat']
        },
      }
	});

	grunt.loadNpmTasks('grunt-contrib-concat');	//load concat module

  //grunt.loadNpmTasks('grunt-contrib-uglify'); //load minification module

  grunt.loadNpmTasks('grunt-contrib-watch');

	grunt.registerTask('default', ['concat', 'watch']);	//execute concat function on grunt call
}