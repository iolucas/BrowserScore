Parti.Key = function(keyName) {
	
	var key = keyName;

	this.name = 'key';

	this.getKey = function() {
		return key;
	}

	/*function getKeyName(keyVal) {

		switch(keyVal) {

			case '-7':
				return 'Cb';

			case '-6':
				return 'Gb';

			case '-5':
				return 'Db';

			case '-4':
				return 'Ab';

			case '-3':
				return 'Eb';

			case '-2':
				return 'Bb';

			case '-1':
				return 'F';

			case '1':
				return 'G';

			case '2':
				return 'D';

			case '3':
				return 'A';

			case '4':
				return 'E';

			case '5':
				return 'B';

			case '6':
				return 'F#';

			case '7':
				return 'C#';
		}	
	}*/
}