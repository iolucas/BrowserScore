function renderScore(mJson) {

	console.log(mJson);

	var score = new Parti.Score();

	foreach(mJson.parts, function(part) {

		var staff = new Parti.Staff();
		score.addStaff(staff);

		var staffNoteDivisions = 1;

		foreach(part.measures, function(measure) {

			var fileMeasure = new Parti.Measure();
			staff.addMeasure(fileMeasure);

			var lastChord = null;	//Last chord ref to handle notes

			foreach(measure.members, function(member) {

				if(member.name == 'attributes') {

					//Set the note divisions
					//Not in use due to influentiate only in music reproduction, not score sheet
					if(member.hasOwnProperty('divisions')) {
						//staffNoteDivisions = parseInt(member.divisions);
					}

					//If there is a clef on the attribute
					if(member.hasOwnProperty('clef')) {
						fileMeasure.addMember(new Parti.Clef(
							getClefName(member.clef.sign + member.clef.line),
							getClefOctaveAnnotation(member.clef['clef-octave-change']))
						);
					}

					if(member.hasOwnProperty('key')) {
						fileMeasure.addMember(new Parti.Key(getKeyName(member.key)));
					}

					if(member.hasOwnProperty('time')) {

						var timeSig;

						if(member.time.hasOwnProperty('symbol')) {
							timeSig = getTimeSymbol(member.time['symbol']);
						} else {
							timeSig = member.time['beats'] + '/' + member.time['beat-type'];
						}

						fileMeasure.setTimeSignature(timeSig);
					}

					//Clear last chord reference in case some attribute showup
					lastChord = null;

				} else if(member.name == 'note') {

					var fileChord = new Parti.Chord();
					fileMeasure.addMember(fileChord);

					//var chordDuration = getDurationName(4 * staffNoteDivisions / parseInt(member.duration));
					var chordDuration = getDurationName(member.type);

					fileChord.setDuration(chordDuration);

					if(member.hasOwnProperty('grace'))
						fileChord['grace'] = member['grace'];

					//Set stem direction
					fileChord.stem = member.stem;

					foreach(member.keys, function(key) {
						//If the key is not a rest
						if(!key.isRest) {
							var noteObj = { 
								note: key.pitch.step, 
								octave: key.pitch.octave 
							}

							if(key.accidental)
								noteObj.accidental = key.accidental;

							fileChord.addNote(noteObj);
						}
					});

				} else if(member.name == 'bar') {
					var barName = getBarValue(member['bar-style'], member.repeat);

					switch(member.location) {

						case 'left':
							fileMeasure.setStartBar(barName);
							break;

						case 'right':
							fileMeasure.setEndBar(barName);
							break;
					}
				}

			});

		});

	});

	score.render();
}


function renderScore2(mJson) {

	console.log(mJson);
	var canvas = $("canvas")[0];
	var renderer = new Vex.Flow.Renderer(canvas, Vex.Flow.Renderer.Backends.CANVAS);
	var ctx = renderer.getContext();
	

	foreach(mJson.parts, function(part) {
		renderStaff(ctx, part);
	});


}



function foreach(array, callback) {
	for (var i = 0; i < array.length; i++) {
		callback.call(this, array[i], i == 0, i == array.length - 1);
	}
}

function getClefName(clefString) {
	switch(clefString) {

		//G clefs
		
		case 'G1':
			return 'french';

		case 'G2':
			return 'treble';



		//F clefs

		case 'F3':
			return 'baritone-f';

		case 'F4':
			return 'bass';

		case 'F5':
			return 'subbass';


		//C clefs

		case 'C1':
			return 'soprano';

		case 'C2':
			return 'mezzo-soprano';

		case 'C3':
			return 'alto';

		case 'C4':
			return 'tenor';

		case 'C5':
			return 'baritone-c';
	}
}

function getClefOctaveAnnotation(octave) {

	if(octave === undefined)
		return undefined;

	switch(octave) {

		case '-1':
			return '8vb';

		case '1':
			return '8va';

		default:
			console.warn('Not Implemented annotation: ' + octave + '. Annotation supressed.');
			return undefined;
	}

}

function getKeyName(keyVal) {

	switch(keyVal) {

		case '-7':
			return 'Cb';

		case '-6':
			return 'Gb';

		case '-5':
			return 'Db';

		case '-4':
			return 'Ab';

		case '-3':
			return 'Eb';

		case '-2':
			return 'Bb';

		case '-1':
			return 'F';

		case '1':
			return 'G';

		case '2':
			return 'D';

		case '3':
			return 'A';

		case '4':
			return 'E';

		case '5':
			return 'B';

		case '6':
			return 'F#';

		case '7':
			return 'C#';
	}	
}

function getTimeSymbol(symbol) {

	switch(symbol) {

		case 'cut':
			return 'C|';

		case 'common':
			return 'C';
	}

	return symbol;

}

function getBarValue(bar, repeat) {

	switch(bar) {

		case 'regular':
			return 'single';
			
		case 'dotted':
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'dashed':
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'heavy':
			//Probably this bar does not exists
			return undefined;

		case 'light-light':
			return 'double';

		case 'light-heavy':
			if(repeat && repeat == 'backward')
				return 'repeat_end';
			else
				return 'end';

		case 'heavy-light':
			if(repeat && repeat == 'forward')
				return 'repeat_begin';
			else
				return undefined;

		case 'heavy-heavy':
			//Probably this bar does not exists
			return undefined;

		case 'tick': //(a short stroke through the top line)
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'short': //(a partial barline between the 2nd and 4th lines)
			console.warn('Not implemented bar: ' + bar + '. Using no bar');
			return undefined;

		case 'none':
			return 'none';
	}
}

function getDurationName(durationValue) {

	switch(durationValue) {

		case 1:
			return 'w';

		case 2:
			return 'h';

		case 4:
			return 'q';

//----------------------------------------

		//Not implemented on vexflow
		//case 'maxima':
		//case 'long':
		//case 'breve'

		case 'whole':
			return 'w';

		case 'half':
			return 'h';

		case 'quarter':
			return 'q';

		case 'eighth':
			return '8';

		case '16th':
			return '16';

		case '32nd':
			return '32';

		case '64th':
			return '64';

		case '128th':
			return '128';

		//case '256th':
		//case '512th':
		//case '1024th':

		default:
			return durationValue.toString();
	}
}


