Parti.Time = function(timeValue) {
	
	var timeVal = timeValue;

	this.name = 'time';

	this.getTime = function() {
		return timeVal;
	}
}