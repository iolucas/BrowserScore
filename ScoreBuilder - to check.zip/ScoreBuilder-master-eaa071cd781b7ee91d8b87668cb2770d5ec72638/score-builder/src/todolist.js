console.log('');
console.log('-------TODO LIST-------');

function todo(msg) {
	console.log('-> ' + msg);
}

todo('Become a competitor to the existing one');
todo('No open source for a while');

todo('keep adding render features, such notes, rests, beams, slurs etc');
todo('Fix bug in case time signature product odd durations values');
todo('Fix bug that stem do not extend to the middle of the score lines');
todo('create proper project to store this');
todo("keep doing the music xml parser");
todo('create lib musicxmlgraphreducer, a that will have only the graphical data of the music xml, simplified but will use all music xml tag names');
todo('If ibr works, we will buy envi.ae and revive qeek.me');
todo('use the visual test vex flow uses');
todo('focus on brazilian market');
todo('main screen will have popular scores, with images or colors created based on the music');
todo('improve the new lines rules');
todo('stem high bug, stem does not grows, overlap other components must be fixed')


console.log('-------------------------');
console.log(' ');