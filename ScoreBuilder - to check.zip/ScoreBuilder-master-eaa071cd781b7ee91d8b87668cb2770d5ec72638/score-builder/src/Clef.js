Parti.Clef = function(clefName, annotation) {

	this.name = 'clef';

	//Clef value
	var _clef = clefName;
	this.getClef = function() {
		return _clef;
	}

	//Annotation in case octave change
	var _annotation = annotation;
	this.getAnnotation = function() {
		if(_clef == "treble" || _clef == "bass")
			return _annotation;

		return undefined;
	}
}