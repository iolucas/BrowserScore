
Parti.Score = function() {

	var staffs = [];

	//console.log(new Vex.Flow.Formatter());
	//console.log([Vex.Flow.Formatter]);

	this.addStaff = function(staff) {
		staffs.push(staff);
	}

	function getChordsLength(chords) {

		// Start by creating a voice and adding all the notes to it.
    	var voice = new Vex.Flow.Voice(Vex.Flow.TIME4_4)
      		.setMode(Vex.Flow.Voice.Mode.SOFT);
    
    	voice.addTickables(chords);

    	var formater = new Vex.Flow.Formatter();
    	return formater.preCalculateMinTotalWidth([voice]);
	}

	this.render = function() {

		var scoreLines = [];
		var scoreLinesIndex = -1;	//Start index with -1 to initiate it correcly

		//Iterate thru staffs and measures and populate score lines array
		for (var i = 0; i < staffs.length; i++) {

			var staffData = staffs[i];

			var currentClef = null;

			staffData.foreach(function(measureData, firstMeasure, lastMeasure, measureIndex) {

				var measureMembers = [];

				measureData.foreach(function(memberData, firstMember, lastMember) {

					if(memberData.name == 'chord') {

						if(currentClef == null)
							throw 'Invalid Chord: No clef has been set to the staff yet';

						var chordKeys = [];
						var chordDuration = getDurationName(memberData.getDuration());

						memberData.foreach(function(noteData) {
							chordKeys.push(noteData.note + "/" + noteData.octave);
						});

						var isRest = chordKeys.length == 0;

						measureMembers.push(new Vex.Flow.StaveNote({ 
							clef: currentClef,
							keys: isRest ? [getCenterString(currentClef)] : chordKeys, 
							duration: isRest ? chordDuration + 'r' : chordDuration,
							auto_stem: true
						}));

					} else if(memberData.name == 'clef') {
						currentClef = memberData.getClef();
					} 


				});

				var chordsLength = getChordsLength(measureMembers);

				//Check if the scoreLine array has been initiated, 
				//if its length is not overflowed and 
				//if its width is not overflowed

				if(scoreLinesIndex > -1 && 
					scoreLines[scoreLinesIndex].measures.length < 8 &&
					scoreLines[scoreLinesIndex].width + chordsLength < 1000) {

					scoreLines[scoreLinesIndex].measures.push(measureData);
					scoreLines[scoreLinesIndex].width += chordsLength;

				} else {
					//If not, increase score lines index, and add the current measuredata to it

					scoreLinesIndex++;
					scoreLines[scoreLinesIndex] = {
						measures: [measureData],
						width: chordsLength
					}

				}

					

			});
		}

		//Now we have the lines, we render them correctly

		var canvas = $("#score-container")[0];
		var renderer = new Vex.Flow.Renderer(canvas, Vex.Flow.Renderer.Backends.RAPHAEL);
		var context = renderer.getContext();

		var renderObjectsQueue = [];

		var renderWindowWidth = 1400;

		var measureVerticalPosPointer = 180;

		currentClef = null;	//reset the current clef
		var currentOctaveShift = 0;
		var currentClefAnnotation;

		var currentTime;
		var currentKey;

		var prevMeasure = null;
		var prevMeasureData = null;

		for (var i = 0; i < scoreLines.length; i++) {
			var scoreLine = scoreLines[i];

			for (var j = 0; j < scoreLine.measures.length; j++) {
				var measureData = scoreLine.measures[j];
				
				//Later we must add weights according to the line minimal space
				var measureWidth = renderWindowWidth / scoreLine.measures.length;

				var measureMembers = [];

				var measure = new Vex.Flow.Stave(j * (measureWidth + 10) + 20, 
					measureVerticalPosPointer, measureWidth)
					.setContext(context);

				//Place begin repeat bar if some or place a repeat both bar in the previous if needed

				if(measureData.getStartBar() == 'repeat_begin') {

					//If first measure of the line
					if(j == 0) {
						//Place the repeat begin bar
						measure.setBegBarType(getBarType('repeat_begin'));
					} else { //If not, 

						//Check if the prev measure
						if(prevMeasureData.getEndBar() == "repeat_end") {
							prevMeasure.setEndBarType(getBarType("repeat_both"));
							measure.setBegBarType(getBarType('none'));
						} else {
							prevMeasure.setEndBarType(getBarType("repeat_begin"));
							measure.setBegBarType(getBarType('none'));
						}
					}

				} else {
					measure.setBegBarType(getBarType('none'));
				}

				//Place end bar if there is some
				var endBar = measureData.getEndBar();
				if(endBar != 'none') {
					measure.setEndBarType(getBarType(endBar));
				}

				//Place the time signature
				var measureTimeSig = measureData.getTimeSignature();

				if(measureTimeSig && measureTimeSig != currentTime) {

					currentTime = measureTimeSig;

					if(j == 0)
						measure.setTimeSignature(currentTime);

					if(prevMeasure)
						prevMeasure.setEndTimeSignature(currentTime);							
				}

				//Place clef in case first measure and clef already signed
				if(j == 0 && currentClef) //first measure of the line
					measure.setClef(currentClef, "default", currentClefAnnotation);

				//Place the current key signature if there is some
				if(j == 0 && currentClef && currentKey)
					//Set the current key signature of the measure
					measure.setKeySignature(currentKey, undefined, undefined, currentClef);

				//Flag to signalize whether a note has already been placed in the measure
				var notePlacedFlag = false;

				//Queue to accumulate note beams to be rendered
				var noteBeamRenderQueue = [];
				var nbrqIndex = -1;	//Index for the note beam render queue

				//Pointer to hold the reference for the last memberData
				var lastMemberData = null;

				measureData.foreach(function(memberData, isFirstMember, isLastMember) {
					//TODO: Use the same data generated for the line to avoid process same thing twice
					if(memberData.name == 'chord') {

						notePlacedFlag = true;

						var chordKeys = [];
						var chordDuration = memberData.getDuration();

						//Queue to hold note accidents to be added at once
						var accidentalQueue = [];
						var accNoteIndex = 0;

						memberData.foreach(function(noteData) {
							chordKeys.push(noteData.note + "/" + noteData.octave);
							
							//Push the accidental to the queue if some
							if(noteData.accidental) {
								accidentalQueue.push({
									index: accNoteIndex,
									accidental: getAccidentalLetter(noteData.accidental.type),
									cautionary: noteData.accidental.cautionary
								});
							}

							accNoteIndex++;
						});

						var isRest = chordKeys.length == 0;

						var staveNote;

						if(memberData.hasOwnProperty('grace')) {

							staveNote = new Vex.Flow.GraceNote({ 
								octave_shift: currentOctaveShift,
								clef: currentClef,
								keys: isRest ? [getCenterString(currentClef, currentOctaveShift)] : chordKeys, 
								duration: isRest ? chordDuration + 'r' : chordDuration,
								auto_stem: memberData.stem ? false : true,
								stem_direction: memberData.stem == 'up' ? 1 : -1,
								slash: memberData.grace.slash
							});

							//If the duration is less than four, so no beam should be placed
							//(Here we use a hack, since the durations that have no beams return letters, not numbers)
							if(!isNaN(parseInt(memberData.getDuration()))) {
								//Check if a new grace group for beaming must be created
								if(lastMemberData == null || //if there is no last member data
									//if the last member were not a grace not
									!lastMemberData.hasOwnProperty('grace') || 
									//If the last member were a grace but with a smaller duration
									//(same hack as above)
									isNaN(parseInt(lastMemberData.getDuration()))) {

									nbrqIndex++;
									noteBeamRenderQueue[nbrqIndex] = [staveNote];	
								} else {
									console.log(lastMemberData.getDuration());
									noteBeamRenderQueue[nbrqIndex].push(staveNote);
								}
							}

						} else {

							staveNote = new Vex.Flow.StaveNote({ 
								octave_shift: currentOctaveShift,
								clef: currentClef,
								keys: isRest ? [getCenterString(currentClef, currentOctaveShift)] : chordKeys,
								auto_stem: memberData.stem ? false : true,
								stem_direction: memberData.stem == 'up' ? 1 : -1, 
								duration: isRest ? chordDuration + 'r' : chordDuration,
								auto_stem: true,
							});

						}

						//Add the queued accidentals to the stave note
						for (var accIndex = 0; accIndex < accidentalQueue.length; accIndex++) {
							var acc = accidentalQueue[accIndex];

							var accObj = new Vex.Flow.Accidental(acc.accidental);

							if(acc.cautionary)
								accObj.setAsCautionary();

							staveNote.addAccidental(acc.index, accObj);
						}

						measureMembers.push(staveNote);

					} else if(memberData.name == 'clef') {

						currentClef = memberData.getClef();
						var clefAnnotation = memberData.getAnnotation();

						//Validate and get annotations to supported clefs
						currentClefAnnotation = validateAnnotation(currentClef, clefAnnotation);

						//Get the octave shift value based on annotation for notes
						currentOctaveShift = getOctaveShift(currentClefAnnotation);


						if(notePlacedFlag) {
							
							//Verification to avoid overlapping of the clef symbol into the bars in case last clef
							if(isLastMember || false) {
								measure.setEndClef(currentClef, "small", currentClefAnnotation);
							} else {
								measureMembers.push(
									new Vex.Flow.ClefNote(currentClef, "small", currentClefAnnotation));
							}

						} else { //If notes were not placed yet

							if(j == 0) //first measure of the line
								measure.setClef(currentClef, "default", currentClefAnnotation);

							if(prevMeasure)
								prevMeasure.setEndClef(currentClef, "small", currentClefAnnotation);
						}
						

					} else if(memberData.name == 'key') {
						
						if(currentClef == undefined)
							throw 'Key Signature Error: No clef has been set yet.';

						//Place the measure key signature
						var measureKeySig = memberData.getKey();
						if(measureKeySig != currentKey) {
					
							currentKey = measureKeySig;

							//If it is there first line, set the key signature
							if(j == 0)
								measure.setKeySignature(currentKey, undefined, undefined, currentClef);

							//Set the prev measure the current signature
							if(prevMeasure)
								prevMeasure.setEndKeySignature(currentKey, undefined, currentClef);									
						}

					} 

					lastMemberData = memberData;
				});

				//Get the current member ref into the prev member var
				prevMeasure = measure;
				prevMeasureData = measureData;

				//Add objects to the render queue to be processed later

				renderObjectsQueue.push({
					type: 'measure',
					measure: measure
				});

				renderObjectsQueue.push({
					type: 'format',
					context: context,
					measure: measure,
					measureMembers: measureMembers
				});

				//Put beams to the render queue
				for (var nbIndex = 0; nbIndex < noteBeamRenderQueue.length; nbIndex++) {
					var noteBeamGroup = noteBeamRenderQueue[nbIndex];

					if(noteBeamGroup.length < 2)
						continue;

					renderObjectsQueue.push({
						type: 'beam',
						beam: new Vex.Flow.Beam(noteBeamGroup)
					});
				}

				stem high bug, stem does not grows, overlap other components must be fixed
				must check the overall design of the project to ensure everything is going ok, and not growing unstable

			}

			measureVerticalPosPointer += 100;
		}

		//Now everything is prepared we may render it

		for (var i = 0; i < renderObjectsQueue.length; i++) {
			switch(renderObjectsQueue[i].type){

				//Draw measure
				case 'measure':
					renderObjectsQueue[i].measure.draw();
					break;

				//Format and position measure members
				case 'format':
					Vex.Flow.Formatter.FormatAndDraw(renderObjectsQueue[i].context, 
						renderObjectsQueue[i].measure, 
						renderObjectsQueue[i].measureMembers);	
					break;

				//Draw notes beams
				case 'beam':
					console.log('hola');
					renderObjectsQueue[i].beam.setContext(context).draw();
					break;
			}
		}
	}

	/*function getDurationName(durationValue) {

		switch(durationValue) {

			case 1:
				return 'w';

			case 2:
				return 'h';

			case 4:
				return 'q';

			default:
				return durationValue.toString();
		}
	}*/

	function validateAnnotation(clef, annotation) {
		var validAnnotation = annotation;	//Default the valid annotation with the argument

		if(annotation == '8va') {
			if(clef != 'treble') {
				console.warn('Not supported anottation for target clef: ' + 
					clef + ' ' + annotation + '. Clearing annotation.');
				validAnnotation = undefined; //If not valid, clear valid annotation
			}
		} else if(annotation == '8vb') {
			if(clef != 'treble' && clef != 'bass') {
				console.warn('Not supported anottation for target clef: ' + 
					clef + ' ' + annotation + '. Clearing annotation.');
				validAnnotation = undefined;
			}
		}

		return validAnnotation;
	}

	function getOctaveShift(annotation) {
		var octaveShift = 0;

		//Get the octave shift value based on annotation
		if(annotation == '8va')
			octaveShift = 1;
		else if(annotation == '8vb')
			octaveShift = -1;

		return octaveShift;
	}

	function getBarType(bar) {

		var barObj = Vex.Flow.Barline.type;

		switch(bar) {

			case 'single':
				return barObj.SINGLE;

			case 'double':
				return barObj.DOUBLE;

			case 'end':
				return barObj.END;

			case 'repeat_begin':
				return barObj.REPEAT_BEGIN;

			case 'repeat_end':
				return barObj.REPEAT_END;

			case 'repeat_both':
				return barObj.REPEAT_BOTH;

			case 'none':
				return barObj.NONE;

			default:
				return barObj.NONE;
		}
	}

	//Function to get the center note to place rest on the center of the stave
	function getCenterString(clef, octaveShift) {

		octaveShift = octaveShift || 0;

		var centerNote = 'b';
		var centerOctave = 4 + octaveShift;

		switch(clef) {

    		case "treble":
				centerNote = 'b';
				centerOctave = 4 + octaveShift;
				break;

    		case "bass":
				centerNote = 'd';
				centerOctave = 3 + octaveShift;
				break;

    		case "alto":
				centerNote = 'c';
				centerOctave = 4 + octaveShift;
				break;

    		case "tenor":
				centerNote = 'a';
				centerOctave = 3 + octaveShift;
				break;

    		case "percussion":
				//centerNote = 'b';
				//centerOctave = 4 + octaveShift;
				break;

    		case "soprano":
				centerNote = 'g';
				centerOctave = 4 + octaveShift;
				break;

    		case "mezzo-soprano":
				centerNote = 'e';
				centerOctave = 4 + octaveShift;
				break;

    		case "baritone-c":
				centerNote = 'f';
				centerOctave = 3 + octaveShift;
				break;

    		case "baritone-f":
				centerNote = 'f';
				centerOctave = 3 + octaveShift;
				break;

    		case "subbass":
				centerNote = 'b';
				centerOctave = 2 + octaveShift;
				break;

    		case "french":
				centerNote = 'd';
				centerOctave = 5 + octaveShift;
				break;

    		//case "tab":
				//centerNote = 'b';
				//centerOctave = 4 + octaveShift;
				//break;
		}

		return centerNote + "/" + centerOctave;
	}

	function getAccidentalLetter(acc) {
		switch(acc) {

			case 'sharp':
  				return "#";

  			case 'double-sharp':
 				return "##";

 			case 'sharp-sharp':
 				return "##";

 			case 'flat':
				return "b";

			case 'flat-flat':
				return "bb";

			case 'natural':
				return "n";


			//return "{"; {   // Left paren for cautionary accidentals

			//return "}"; {   // Right paren for cautionary accidentals

			/*case 'sharp':
				return "db";

			case 'sharp':
				return "d";

			case 'sharp':
				return "bbs";

			case 'sharp':
				return "++";

			case 'sharp':
				return "+";

			case 'sharp':
				return "+-";

			case 'sharp':
				return "++-";

			case 'sharp':
				return "bs";

			case 'sharp':
				return "bss";*/

			default:
				throw 'Accidental not implemented: ' + acc;
		}
	}
}