//Main object declaration

var Parti = {}