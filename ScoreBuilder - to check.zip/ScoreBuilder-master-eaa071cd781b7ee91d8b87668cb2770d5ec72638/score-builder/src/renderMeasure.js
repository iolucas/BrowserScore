//Function to render the score measures
function renderMeasure(measure, staff) {


	//create object to wrap vexflow components and improve the objectification of the score,
	//creating measures etc


}